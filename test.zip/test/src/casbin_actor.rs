use casbin::prelude::*;
use actix::prelude::*;
use actix::fut::*;
use casbin::{Result, Error as CasbinError};


pub struct CasbinActor {
    enforcer: Option<Enforcer>
}
impl CasbinActor {
    pub async fn new<M: TryIntoModel, A: TryIntoAdapter>(m: M, a:A)
    -> Result<Addr<CasbinActor>> {
        let enforcer: Enforcer = Enforcer::new(m,a).await?;
        Ok(Supervisor::start(|_| CasbinActor {
            enforcer: Some(enforcer)
        }))
    }
}

impl Actor for CasbinActor {
    type Context = Context<Self>;

}


impl Supervised for CasbinActor {
    fn restarting(&mut self, _: &mut Self::Context) {
        self.enforcer.take();
    }
}


pub enum CasbinCmd {
    Enforce(Vec<String>),
    AddPolicy(Vec<String>),
    AddPolicies(Vec<Vec<String>>),
    RemovePolicy(Vec<String>),
    RemovePolicies(Vec<Vec<String>>),
    RemoveFilteredPolicy(usize,Vec<String>),
}

impl Message for CasbinCmd {
    type Result = Result<bool>;
}

impl Handler<CasbinCmd> for CasbinActor {
    type Result = ResponseActFuture<Self, Result<bool>>;

    fn handle(&mut self, msg: CasbinCmd, _: &mut Self::Context) -> Self::Result {
        if let Some(ref mut e) = self.enforcer {
            let send = match msg {
                CasbinCmd::Enforce(str) => e.enforce(&str),
                CasbinCmd::AddPolicy(str) => e.add_policy(str),
                CasbinCmd::AddPolicies(str) => e.add_policies(str),
                CasbinCmd::RemovePolicy(str) => e.remove_policy(str),
                CasbinCmd::RemovePolicies(str) => e.remove_policies(str),
                CasbinCmd::RemoveFilteredPolicy(idx,str) => e.remove_filtered_policy(idx,str),
            };
            let send =  actix::fut::wrap_future::<_, Self>(send);
            let return_send = send.map(|res,_act,_ctx|{
                res
            });
            Box::new(return_send)
        }
        else{
            Box::new(err::<bool,CasbinError,Self>(CasbinError::IoError(std::io::Error::new(std::io::ErrorKind::NotConnected,"Enforcer need"))))
        }
    }
}
