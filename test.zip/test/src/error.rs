use casbin::Error as CasbinError;

use std::{error::Error as StdError, fmt};

#[derive(Debug)]
pub enum Error {
    CasbinError(CasbinError),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        use Error::*;

        match self {
            PoolError(pool_err) => pool_err.fmt(f),
            DieselError(diesel_error) => diesel_error.fmt(f),
        }
    }
}

impl StdError for Error {
    fn source(&self) -> Option<&(dyn StdError + 'static)> {
        use Error::*;

        match self {
            PoolError(pool_err) => Some(pool_err),
            DieselError(diesel_error) => Some(diesel_error),
        }
    }
}

impl From<PoolError> for Error {
    fn from(err: PoolError) -> Self {
        Error::PoolError(err)
    }
}

impl From<DieselError> for Error {
    fn from(err: DieselError) -> Self {
        Error::DieselError(err)
    }
}
