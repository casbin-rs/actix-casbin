use actix_casbin::{CasbinActor,CasbinCmd};
use casbin::{prelude, FileAdapter};

#[actix_rt::test]
async fn test_enforcer() {
    let mut m = DefaultModel::from_file("examples/rbac_model.conf").await.unrap();
    let mut a = FileAdapter::new("examples/rbac_policy.csv").await.unrap();
    let addr = CasbinActor::new(m,a);
    let enforce = addr.send(CasbinCmd(Enforce(&vec!["alice", "data1", "read"]))).await?;
    assert_eq!(true,enforce);
}

