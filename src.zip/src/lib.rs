extern crate casbin;
mod casbin_actor;
pub use casbin_actor::{CasbinActor,CasbinCmd};